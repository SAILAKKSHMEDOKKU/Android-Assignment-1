package com.example.bookreviewapp.data.api;

import com.example.bookreviewapp.domain.model.Book;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface BookApiService {
    @GET("books.json") // Replace with actual mock URL later
    Call<List<Book>> getBooks();
}
