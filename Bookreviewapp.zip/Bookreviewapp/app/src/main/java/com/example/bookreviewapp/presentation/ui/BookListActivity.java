package com.example.bookreviewapp.presentation.ui;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookreviewapp.R;
import com.example.bookreviewapp.domain.model.Book;
import com.example.bookreviewapp.presentation.viewmodel.BookViewModel;

import java.util.List;

public class BookListActivity extends AppCompatActivity {

    private BookViewModel viewModel;
    private RecyclerView recyclerView;
    private BookListAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_list);

        recyclerView = findViewById(R.id.recyclerViewBooks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BookListAdapter(this);
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(BookViewModel.class);

        viewModel.getBooks().observe(this, books -> {
            if (books != null) {
                adapter.setBookList(books);
            }
        });
    }
}
