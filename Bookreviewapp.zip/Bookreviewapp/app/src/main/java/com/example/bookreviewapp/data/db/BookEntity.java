package com.example.bookreviewapp.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "favorites")
public class BookEntity {
    @PrimaryKey
    public int id;
    public String title;
    public String author;
    public String thumbnailUrl;
    public String description;
    public float rating;
}
