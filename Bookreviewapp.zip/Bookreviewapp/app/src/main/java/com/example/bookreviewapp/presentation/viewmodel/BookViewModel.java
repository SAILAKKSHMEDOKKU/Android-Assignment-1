package com.example.bookreviewapp.presentation.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.bookreviewapp.data.db.BookEntity;
import com.example.bookreviewapp.data.repository.BookRepository;
import com.example.bookreviewapp.domain.model.Book;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookViewModel extends AndroidViewModel {

    private MutableLiveData<List<Book>> books = new MutableLiveData<>();
    private BookRepository repository;

    public BookViewModel(Application application) {
        super(application);
        repository = new BookRepository(application);
        loadBooks();
    }

    private void loadBooks() {
        repository.fetchBooksFromNetwork().enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(Call<List<Book>> call, Response<List<Book>> response) {
                books.setValue(response.body());
            }

            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                books.setValue(null);
            }
        });
    }

    public LiveData<List<Book>> getBooks() {
        return books;
    }

    public LiveData<List<BookEntity>> getFavorites() {
        return repository.getFavorites();
    }

    public void saveFavorite(BookEntity book) {
        repository.addFavorite(book);
    }
}
