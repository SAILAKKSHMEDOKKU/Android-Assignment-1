package com.example.bookreviewapp.presentation.ui;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.bookreviewapp.R;

public class BookDetailActivity extends AppCompatActivity {

    TextView textBookTitle, textBookAuthor, textBookDescription, textBookRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        textBookTitle = findViewById(R.id.textBookTitle);
        textBookAuthor = findViewById(R.id.textBookAuthor);
        textBookDescription = findViewById(R.id.textBookDescription);
        textBookRating = findViewById(R.id.textBookRating);

        textBookTitle.setText(getIntent().getStringExtra("book_title"));
        textBookAuthor.setText(getIntent().getStringExtra("book_author"));
        textBookDescription.setText(getIntent().getStringExtra("book_description"));
        textBookRating.setText("Rating: " + getIntent().getFloatExtra("book_rating", 0));
    }
}
