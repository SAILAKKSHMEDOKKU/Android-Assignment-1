package com.example.bookreviewapp.data.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import androidx.room.Room;

import com.example.bookreviewapp.data.api.BookApiService;
import com.example.bookreviewapp.data.db.AppDatabase;
import com.example.bookreviewapp.data.db.BookDao;
import com.example.bookreviewapp.data.db.BookEntity;
import com.example.bookreviewapp.domain.model.Book;
import com.example.bookreviewapp.utils.RetrofitClient;

import java.util.List;

import retrofit2.Call;

public class BookRepository {
    private BookApiService apiService;
    private BookDao bookDao;

    public BookRepository(Application application) {
        apiService = RetrofitClient.getInstance().create(BookApiService.class);
        AppDatabase db = Room.databaseBuilder(application, AppDatabase.class, "book_db").build();
        bookDao = db.bookDao();
    }

    public Call<List<Book>> fetchBooksFromNetwork() {
        return apiService.getBooks();
    }

    public void addFavorite(BookEntity book) {
        new Thread(() -> bookDao.insert(book)).start();
    }

    public LiveData<List<BookEntity>> getFavorites() {
        return bookDao.getAllFavorites();
    }
}
